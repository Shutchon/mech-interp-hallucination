# Supplementary Material

This archive contains all data and scripts needed to verify the results
in the manuscript. Files are organized to map directly to the paper's
tables and figures.

## Directory Structure

### splits/ — Relation and case IDs (Tables 2, 9)
| File | Maps to |
|------|---------|
| gemma_dev_heldout.json | Table 2 behavioral baselines (dev/held-out split) |
| llama_dev_heldout.json | Table 9 cross-model replication |
| qwen_dev_heldout.json | Table 9 cross-model replication |

### heads/ — Head lists for every configuration (Tables 5–8)
| File | Maps to |
|------|---------|
| gemma_head_lists.json | dev_ranking_top20, topnorm5, spec1, spec3, mean5, mean2, random1_uniform, random1_late |
| llama_heads.json | fine_top10 (Table 9) |
| qwen_heads.json | fine_top10 (Table 9) |

### per_item/ — Raw per-item outcomes (all Tables 4–9, Figures 2–5)
| File | Maps to |
|------|---------|
| gemma_round1_per_item.jsonl | Table 7 (dose-response: none, top-k, topnorm, random-5) |
| gemma_round2_per_item.jsonl | Table 7 (spec1, spec3, mean configs) |
| gemma_random1_per_item.jsonl | Table 8 (random-1 and late-rand-1 per-head) |
| gemma_correct_ctx_per_item.jsonl | Correct-context control (Sect. 4.3) |
| gemma_mmlu_paired_perq.jsonl | MMLU paired test (Table 8, McNemar b=22 c=30) |
| gemma_capability_unified.json | Table 8 (unified MMLU + PPL for all 16 configs) |
| llama_e5_per_item.jsonl | Table 9 (Llama held-out interventions) |
| qwen_e5_per_item.jsonl | Table 9 (Qwen held-out interventions) |
| precision_parity.json | Sect. 4.1 precision robustness (fp32 vs bf16) |
| neutral_fp32.json | Table 4 (float32 neutral-effect check, 4 heads) |
| superposition_summary.json | Table 5 (per-head A/B/N/S values), Figure 4 |
| stats_bootstrap_mcnemar.json | All bootstrap CIs and McNemar tests in Tables 7, 9 |
| stats_round2b.json | MMLU paired test, cross-model CIs, correct-context test |
| fig3_attention_data.json | Figure 4 (attention patterns + answer-position stats) |

### scripts/ — Analysis and figure-generation code
| Script | Produces |
|--------|----------|
| analysis_stats.py | stats_bootstrap_mcnemar.json (CIs, McNemar) |
| analysis_round2.py | stats_bootstrap_mcnemar.json (round-2 additions) |
| analysis_round2b.py | stats_round2b.json (MMLU paired, cross-model) |
| make_figures.py | Figures 2, 5 (layer profiles, trade-off) |
| make_figures13.py | Figures 1, 4 (pipeline, attention) |
| make_fig3_v2.py | Figure 4 (attention from fig3_attention_data.json) |
| e0_parity_check.py | E0 framework parity |
| e0b_metric_parity.py | precision_parity.json |
| e1_build_dataset.py | Dataset construction + known-fact filter |
| e3_patching_sweep.py | E3 coarse/mid/fine patching |
| e4_superposition.py | superposition_summary.json |
| e4b_neutral_fp32.py | neutral_fp32.json |
| e5_interventions.py | Dose-response round 1 |
| e5_round2.py | spec/mean configs round 2 |
| e5_mmlu_ppl.py | MMLU + PPL capability |
| e5b_mmlu_perq.py | MMLU per-question records |
| e5c_correct_context.py | Correct-context control |
| e5d_extra_baselines.py | random-1 / late-rand-1 baselines |
| e5e_followups.py | Full-answer check + random capability |
| e5f_followups.py | Robust full-answer + rand-head capability |
| e5g_capability_unified.py | gemma_capability_unified.json |
| e6_cross_model.py | Cross-model pipeline |
| e6b_peritem.py | Cross-model per-item records |
| fig3_extract.py | fig3_attention_data.json |

### versions/ — Environment details
| File | Content |
|------|---------|
| environment.txt | Python/torch/transformer_lens/numpy versions, GPU model, checkpoint dates |

## Verification Guide

To reproduce the main results:
1. **Table 7**: See `per_item/gemma_round1_per_item.jsonl` and `per_item/gemma_round2_per_item.jsonl`; run `scripts/analysis_stats.py`
2. **Table 8**: See `per_item/gemma_capability_unified.json`; run `scripts/e5g_capability_unified.py`
3. **McNemar tests**: All b,c values in `per_item/stats_bootstrap_mcnemar.json` and `per_item/stats_round2b.json`
4. **Bootstrap CIs**: Computed in `scripts/analysis_round2.py` (fact-clustered, 10,000 resamples)
5. **Precision check**: `per_item/precision_parity.json` and `per_item/neutral_fp32.json`
6. **Figures**: Run `scripts/make_figures.py` and `scripts/make_fig3_v2.py`
